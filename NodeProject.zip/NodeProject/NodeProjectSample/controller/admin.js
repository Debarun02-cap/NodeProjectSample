//Local Modules
const Complaint = require("../models/complaint");
const Status = require("../models/status");

exports.adminHome=(req,res,next)=>{
  Complaint.fetchAll((registeredComplaints)=>{
    const ids = registeredComplaints.map(c=>c.id);
    Status.getLatestForIds(ids,(statusMap)=>{
      res.render('admin/home',{
        registeredComplaints:registeredComplaints,
        statusMap:statusMap
      });
    });
  });
}
exports.getComplaintDetails=(req,res,next)=>{
  const complaintId=req.params.complaintId;
  Complaint.findById(complaintId,complaint=>{
    if(!complaint){
      console.log("Error");
      return res.redirect('/admin/home');
    }

    Status.getForComplaint(complaintId,(statusUpdates)=>{
      res.render('admin/complaintDetails',{
        complaint:complaint,
        statusUpdates:statusUpdates
      });
    });
  });
}

exports.getupdateStatus=(req,res,next)=>{
  const complaintId = req.params.complaintId;
  res.render('admin/statusUpdate',{complaintId:complaintId});
}

exports.postUpdateStatus=(req,res,next)=>{
  const complaintId = req.params.complaintId;
  const {workstatus,title,description,photoUrl,dateTime} = req.body;

  const status = new Status(workstatus,title,description,photoUrl,dateTime);

  Status.addToStatus(complaintId,status,(err)=>{
    if(err){
      console.error('Failed to save status:',err);
      return res.status(500).send('Failed to save status update');
    }
    // After updating status, redirect back to admin dashboard or complaint details
    res.redirect('/admin/home');
  });
}