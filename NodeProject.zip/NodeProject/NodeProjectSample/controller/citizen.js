//Local module
const Complaint = require("../models/complaint");
const Status = require("../models/status");

exports.userHome=(req,res,next)=>{
  Complaint.fetchAll((registeredComplaints)=>{
    const ids = registeredComplaints.map(c=>c.id);
    Status.getLatestForIds(ids,(statusMap)=>{
      res.render('citizen/home',{
        registeredComplaints:registeredComplaints,
        statusMap:statusMap
      });
    });
  });
}
exports.getRegister=(req,res,next)=>{
  res.render('citizen/register');
}


exports.postRegister=(req,res,next)=>{
  console.log("complaint registered"+req.body.title);
  const complaint=new Complaint(req.body.issuetype,req.body.title,req.body.description,req.body.photoUrl,req.body.locationUrl);
  complaint.save();
  res.render('citizen/registeredSuccess');
}

exports.getComplaintDetails=(req,res,next)=>{
  const complaintId=req.params.complaintId;
  Complaint.findById(complaintId,complaint=>{
    if(!complaint){
      console.log("Error");
      return res.redirect('/user/home');
    }

    Status.getForComplaint(complaintId,(statusUpdates)=>{
      res.render('citizen/complaintDetails',{
        complaint:complaint,
        statusUpdates:statusUpdates
      });
    });
  });
}
