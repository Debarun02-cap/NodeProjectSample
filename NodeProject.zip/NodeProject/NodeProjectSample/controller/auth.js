exports.getIndex=(req,res,next)=>{
  res.render('auth/index');
}