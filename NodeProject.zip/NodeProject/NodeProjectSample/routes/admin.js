//External MOdule
const express=require('express');

//Local Module
const root=require('../utils/pathUtil');
const {registeredComplaints}=require('./user')
const adminController=require('../controller/admin')

const ar=express();

ar.get('/home',adminController.adminHome);
ar.get('/complaintDetails/:complaintId',adminController.getComplaintDetails);
ar.get('/updateStatus/:complaintId',adminController.getupdateStatus);
ar.post('/statusUpdate/:complaintId',adminController.postUpdateStatus);

module.exports=ar;