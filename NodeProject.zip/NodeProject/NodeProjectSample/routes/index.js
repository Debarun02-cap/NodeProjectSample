//External MOdule
const express=require('express');

//Local Module
const authController=require('../controller/auth')

const app=express();
app.get('/',authController.getIndex);

module.exports=app;