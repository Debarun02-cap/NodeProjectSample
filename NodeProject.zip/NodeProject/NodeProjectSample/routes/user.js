//Local Module
const root=require('../utils/pathUtil')
const citizenController=require('../controller/citizen')

//External MOdule
const express=require('express');

const ur=express();

ur.get('/home',citizenController.userHome);
ur.get('/register',citizenController.getRegister);
ur.post('/register',citizenController.postRegister);
ur.get('/complaintDetails/:complaintId',citizenController.getComplaintDetails);

exports.ur=ur;
