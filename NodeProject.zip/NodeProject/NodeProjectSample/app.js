//Core Module
const path=require('path')

//External Module
const express=require('express');

//Local Module 
const {ur, registeredComplaints}=require('./routes/user');
const ar=require('./routes/admin');
const ir=require('./routes/index');

const app=express();

app.set('view engine','ejs')

// Static files (css/images) served from /public
app.use(express.static(path.join(__dirname, 'public')));

app.use(express.urlencoded({extended:true}));
app.use(ir);
app.use('/admin',ar);
app.use('/user',ur);

const port=3000;
app.listen(port,()=>{
  console.log(`Server is running on http://localhost:${port}`)
})