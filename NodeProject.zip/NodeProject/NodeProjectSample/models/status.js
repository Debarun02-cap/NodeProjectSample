//Core Modules
const fs=require('fs');
const path=require('path')

//Local Modules
const root=require('../utils/pathUtil');

// Directory where complaint-related data is stored
const dataDir = path.join(root, 'data');
// Path for the new consolidated status.json file
const statusDataPath = path.join(dataDir, 'status.json');

module.exports = class Status {
  constructor(workstatus, title, description, photoUrl, dateTime) {
    this.workstatus = workstatus;
    this.title = title;
    this.description = description;
    this.photoUrl = photoUrl;
    this.dateTime = dateTime;
  }

  // Read and return the whole status.json object (keyed by complaintId)
  static fetchAll(callback){
    fs.readFile(statusDataPath,'utf8',(err,data)=>{
      if(err || !data){
        return callback({});
      }
      try{
        const parsed = JSON.parse(data);
        callback(parsed || {});
      }catch(parseErr){
        console.error('Error parsing status.json, returning empty object:',parseErr);
        callback({});
      }
    });
  }

  // Get all status entries for a single complaintId
  static getForComplaint(complaintId,callback){
    this.fetchAll(allStatuses=>{
      const key = String(complaintId);
      callback(allStatuses[key] || []);
    });
  }

  // For a list of complaintIds, return a map id -> latest status entry
  static getLatestForIds(complaintIds,callback){
    this.fetchAll(allStatuses=>{
      const map = {};
      complaintIds.forEach(id=>{
        const key = String(id);
        const arr = allStatuses[key];
        if(Array.isArray(arr) && arr.length){
          map[key] = arr[arr.length-1];
        }
      });
      callback(map);
    });
  }

  // Adds / appends status details for a complaintId into status.json
  static addToStatus(complaintId, statusInstance, callback) {
    if (!complaintId) {
      const err = new Error('complaintId is required to save status');
      console.error(err.message);
      if (callback) callback(err);
      return;
    }

    // Ensure data directory exists
    fs.mkdir(dataDir, { recursive: true }, (dirErr) => {
      if (dirErr) {
        console.error('Error ensuring data directory:', dirErr);
        if (callback) callback(dirErr);
        return;
      }

      // Read existing status.json (if any)
      fs.readFile(statusDataPath, 'utf8', (readErr, data) => {
        let allStatuses = {};

        if (!readErr && data) {
          try {
            allStatuses = JSON.parse(data);
          } catch (parseErr) {
            console.error('Error parsing existing status.json, starting fresh:', parseErr);
            allStatuses = {};
          }
        }

        const entry = {
          complaintId: String(complaintId),
          workstatus: statusInstance.workstatus,
          title: statusInstance.title,
          description: statusInstance.description,
          photoUrl: statusInstance.photoUrl,
          dateTime: statusInstance.dateTime,
        };

        // Store an array of status updates per complaintId
        const key = String(complaintId);
        if (!Array.isArray(allStatuses[key])) {
          allStatuses[key] = [];
        }
        allStatuses[key].push(entry);

        fs.writeFile(statusDataPath, JSON.stringify(allStatuses, null, 2), (writeErr) => {
          if (writeErr) {
            console.error('Error writing status.json:', writeErr);
          } else {
            console.log('Status updated in', statusDataPath);
          }
          if (callback) callback(writeErr);
        });
      });
    });
  }
}