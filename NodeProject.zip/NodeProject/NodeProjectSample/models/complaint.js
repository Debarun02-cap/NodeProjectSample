//Core Modules
const fs=require('fs');
const path=require('path')

//Local Modules
const root=require('../utils/pathUtil');
const { error } = require('console');

//Fake Database
let registeredComplaints=[];

//Data Path
const complaintDataPath=path.join(root,'data','complaints.json');

module.exports=class Complaint{
 constructor(issuetype,title,description,photoUrl,locationUrl){
    this.issuetype=issuetype;
    this.title=title;
    this.description=description;
    this.photoUrl=photoUrl;
    this.locationUrl=locationUrl;
 }

 save(){
    this.id=Math.random().toString();
    Complaint.fetchAll((registeredComplaints)=>{
        registeredComplaints.push(this);
        fs.writeFile(complaintDataPath, JSON.stringify(registeredComplaints),error=>{
        console.log("File Written");
      })
    })
 }

 static fetchAll(callback){
  
  fs.readFile(complaintDataPath,(err,data)=>{
    if(err)
    {
      registeredComplaints= [];
    }
    else
    {
      registeredComplaints=JSON.parse(data);
    }
    callback(registeredComplaints);
  }) 
 }

 static findById(complaintId, callback){
  this.fetchAll(complaints=>{
    const complaintFound= complaints.find(complaint=>complaint.id===complaintId);
    callback(complaintFound)
  })
 }
}